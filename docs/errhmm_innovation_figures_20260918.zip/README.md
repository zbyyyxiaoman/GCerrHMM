# Innovation figure package

Generated on 2026-09-18 from the frozen E. coli dataset. No new
simulations or model training were performed.

## Figures

- `figA_gc_error_curve.png/.pdf`
- `figB_homopolymer_deletion.png/.pdf`
- `figC_kmer_pca.png/.pdf`
- `figD_gc_heterogeneity_gain.png/.pdf/.csv`
- `figE_simulator_selection_guide.png/.pdf`

## Important interpretation

- Fig A is an exploratory negative result: the expected monotonic
  GC-error relationship was not recovered after excluding soft-clipped
  bases. The earlier apparent 10x discrepancy was a post-analysis bug:
  pysam `get_aligned_pairs()` exposes soft clips as `query_pos=None,`
  `ref_pos=None`-like insertion-like events. The corrected aligned error
  rates are real `0.56-1.10%`, errHMM `0.49-0.59%`, PBSim3 `0.37-0.63%`.
- Fig B shows that badread, not errHMM, is the tool closest to the real
  homopolymer deletion trend in this frozen E. coli panel.
- Fig C supports errHMM composition-level fidelity.
- Fig D shows a weak heterogeneity-gain association (`r` about `-0.03`).
- Fig E is a conceptual selection guide, not a performance claim.

See `innovation_postanalysis_report.md` for the full interpretation.
