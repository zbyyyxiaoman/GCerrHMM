# Innovation post-analysis report

Date: 2026-09-18

This analysis used frozen E. coli data only. No new simulations or model
training were run. Existing simulated FASTQ files were re-aligned with the
same minimap2/samtools post-analysis pipeline to obtain comparison BAMs.

## P0 correction: soft-clipped bases were counted as insertions

The first version of Fig A counted every query base with `ref_pos is None`
as an insertion. In pysam, `get_aligned_pairs()` also exposes soft-clipped
query bases this way. Real ONT BAMs have substantial soft clipping, so the
real error rate was inflated to 4.5-6.9%, whereas the aligned-region
compound error rate is about 0.6-1.1%. The comparison after excluding
soft-clipped bases is:

| Dataset | Aligned compound error rate |
|---|---:|
| Real ONT | 0.56-1.10% |
| errHMM | 0.49-0.59% |
| NanoSim | 0.68-0.85% |
| PBSim3 | 0.37-0.63% |
| badread | 4.7-5.7% |

This resolves the apparent 10x errHMM discrepancy. It was a post-analysis
metric bug, not evidence that errHMM trains with a 10x-too-low error rate.
badread is intentionally configured for error-prone/degraded reads, so its
high error rate is expected for this dataset and no parameter-matching to
the real read set was performed.

## Fig A: GC-dependent error rate

Result after correction: the expected monotonic GC-error curve is still
not strongly recovered.

- Real ONT error rate was non-monotonic across local GC bins:
  20-30% GC `0.67%`, 30-40% `1.10%`, 40-50% `0.94%`,
  50-60% `0.93%`, 60-70% `0.99%`.
- errHMM was nearly flat (`0.49-0.59%`).
- PBSim3 was nearly flat (`0.37-0.63%`).
- badread was nearly flat (`4.7-5.7%`).
- NanoSim had a different, non-monotonic shape.

Decision: use the corrected panel as a limitation/exploratory result. Do
not use it as evidence that errHMM follows the real GC-error slope.

## Fig B: homopolymer deletion rate

Result: real and badread show increasing deletion rate with homopolymer
length; the other tools are largely flat.

- Real: `0.34%` at length 1 to `14.67%` at length 10.
- badread: `1.68%` at length 1 to `16.36%` at length 10.
- errHMM/PBSim3/NanoSim: approximately `0.1-0.3%` without a clear
  increasing trend.

Decision: do not use Fig B to claim errHMM homopolymer fidelity. The
panel is useful as a limitation and as evidence that badread captures a
different error-structure regime.

## Fig C: k-mer composition PCA

Result: the errHMM cloud is the closest to the real cloud in the frozen
E. coli 5-mer PCA.

Center distance to real (lower is closer):

| Dataset | Distance in PC1-PC2 |
|---|---:|
| errHMM | 0.000085 |
| Route B | 0.000128 |
| PBSim3 | 0.000159 |
| Route C | 0.000264 |
| badread | 0.001178 |
| NanoSim | 0.001845 |
| Route A | 0.003728 |

Decision: Fig C can be used as supporting evidence for composition-level
fidelity, with the caveat that PCA is exploratory and only two dimensions
are shown.

## Fig D: GC heterogeneity versus k-mer gain

Result: the six-species linear association is weak
(Pearson r about `-0.03`). The plot does not support a monotonic
heterogeneity-gain hypothesis. It can appear in Discussion only as an
exploratory scatter with the wording "not strongly consistent" or be
removed.

## Fig E: selection guide

This is a conceptual guide, not a statistical result. It encodes the
species-dependent conclusion and the lack of a universal simulator winner.
