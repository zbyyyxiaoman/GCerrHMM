# chr21 30x delta-to-real decision

Rule: `docs/delta_to_real_framing.md` (pre-registered 2026-09-25).
Data: coverage-matched 30x panel (`results/framework/tables/*_Hsapiens_chr21_30x.json`).
Tie policy: average ranks; top-2 requires an average rank <= 2.

Layers excluded from the ranking (no real anchor exists): R4
## Real anchor

- base identity: 0.8655
- variant F1: 0.0003 (SNP 0.0004, indel 0.0001)
- assembly: 48 contigs, N50 33502007 bp, identity 0.7977

## Per-tool distances

| tool | R3 identity | ΔR3 | R4 F1 | ΔR4 | R5 identity | R5 N50 | rank R3 | rank R4 | rank R5 | top-2 layers |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| GCerrHMM | 0.9144 | 0.0489 | 0.9289 | 0.9286 | 0.9086 | 25035759 | 2.0 | excluded | 1.0 | 2 |
| NanoSim | 0.9020 | 0.0365 | 0.9330 | 0.9327 | 0.9166 | 10036040 | 1.0 | excluded | 3.0 | 1 |
| PBSim3-sample | 0.9657 | 0.1002 | 0.9708 | 0.9705 | 0.9460 | 21483763 | 4.0 | excluded | 4.0 | 0 |
| badread | 0.9478 | 0.0823 | 0.9646 | 0.9643 | 0.9212 | 33744471 | 3.0 | excluded | 2.0 | 1 |

## Decision

GCerrHMM places top-2 in **2 of 2** layers with a real anchor (R3 rank 2.0, R5 rank 1.0).

**Headline: downstream consistency on a GC-heterogeneous eukaryotic genome.** GCerrHMM's distances to the real anchor place it in the top-2 of at least two layers.

## Provenance

- mapping_errhmm_Hsapiens_chr21_30x.json sha256: `069011d8e63388dc3e30a0b2c8a34938b6f9f7fc30c5dc4c4f424c02e5c25675`
- variant_errhmm_Hsapiens_chr21_30x.json sha256: `4deb02709ef6654238f63e665e1fa119dc5d791bd52229960a552fa3ae9e9bda`
- assembly_flye_errhmm_Hsapiens_chr21_30x.json sha256: `6236bb995cb361c648e09ec585569ee11359b25c208176b6bb172df08cdc5c73`
- mapping_nanosim_Hsapiens_chr21_30x.json sha256: `5a48d39143930d662012bf4dfd1d5a1f5a8f91171a577c90a6cb19867f79f040`
- variant_nanosim_Hsapiens_chr21_30x.json sha256: `45a2a139c3d9023d4ced6908329a7690897793ea3105057de9f348db22d49241`
- assembly_flye_nanosim_Hsapiens_chr21_30x.json sha256: `19c26bdf182217ea9072f039f9af6eef0ededd2bf95e14c702ba4da48ae7ecb1`
- mapping_pbsim_Hsapiens_chr21_30x.json sha256: `928331b053dd12a00cbc8588053ce3308397caab25ab6eae6e7f7a38d99e7cd0`
- variant_pbsim_Hsapiens_chr21_30x.json sha256: `17c231a39c17d54b40f744852a0875637d359b0178d342bcf64ce21495a7a7b5`
- assembly_flye_pbsim_Hsapiens_chr21_30x.json sha256: `b7179dd4f50bd1c10dc9b7af227de1351edaf9ac43b17520453329773d329bc2`
- mapping_badread_Hsapiens_chr21_30x.json sha256: `e985d14439fb9d9bfb778a597b0aadd5ce0d0601fa358a13d7fa8c81c3e5fead`
- variant_badread_Hsapiens_chr21_30x.json sha256: `a69a4b48cf65ea0ba0628e293911f4778d7cd30327729bee38c56af57d64581c`
- assembly_flye_badread_Hsapiens_chr21_30x.json sha256: `02bde319cb7d3c5ab9dc5b87189ed08f66610001369d8251b20649fcec59d4cd`

## Reporting commitments

1. The layer where GCerrHMM is not top-2 is named in the abstract-level narrative, not hidden in the supplement.
2. A split between the primary metric and the sub-metrics (for example a top-2 overall F1 driven by SNPs while the indel F1 is last) is reported as the result rather than resolved in the friendlier direction.
