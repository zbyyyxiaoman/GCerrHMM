# HiFi cross-platform seed summary

| Seed | Composite Δ | k-mer Δ | GC Δ | Read-length Δ |
|---:|---:|---:|---:|---:|
| 42 | +3.26 | +15.23 | -0.49 | +1.88 |
| 11 | -0.74 | -5.06 | +0.81 | +0.00 |
| 22 | -1.24 | -7.93 | +1.04 | -0.01 |
| 33 | +0.46 | +2.46 | -0.10 | +0.01 |

Composite Δ mean±SD: +0.435 ± 2.014

k-mer Δ mean±SD: +1.175 ± 10.344

GC Δ mean±SD: +0.315 ± 0.728
