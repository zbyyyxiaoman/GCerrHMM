# Final v2 layer summary

Inputs: coverage-matched `results/framework/tables/*_30x.json`.
Real anchors: 30x ONT mapping/variant tables and Flye assembly JSON.

| layer | metric | real | GCerrHMM | NanoSim | PBSim3-sample | badread | note |
|---|---|---:|---:|---:|---:|---:|---|
| R3 | alignment_base_identity | 0.865538 | 0.914406 | 0.902007 | 0.965744 | 0.94785 | real ONT 30x through the same mapper |
| R4 | variant_f1 | 0.0003 | 0.9289 | 0.933 | 0.9708 | 0.9646 | synthetic truth; cross-tool only and excluded from delta-to-real |
| R5 | assembly_reference_identity | 0.7977 | 0.9086 | 0.9166 | 0.946 | 0.9212 | real ONT 30x through the same Flye protocol |
| R5 | assembly_n50_bp | 33502007 | 25035759 | 10036040 | 21483763 | 33744471 | real ONT 30x through the same Flye protocol |
