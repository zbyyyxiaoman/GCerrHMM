# HiFi cross-platform seed summary

| Seed | Composite Δ | k-mer Δ | GC Δ | Read-length Δ |
|---:|---:|---:|---:|---:|
| 11 | -0.74 | -5.06 | +0.81 | +0.00 |
| 22 | -1.24 | -7.93 | +1.04 | -0.01 |
| 33 | +0.46 | +2.46 | -0.10 | +0.01 |

Composite Δ mean±SD: -0.507 ± 0.874

k-mer Δ mean±SD: -3.510 ± 5.366

GC Δ mean±SD: +0.583 ± 0.603
