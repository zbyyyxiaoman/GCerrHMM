# Teacher framework summary

| Layer | Rows | External species panel |
|---|---:|---|
| Reads / Level-1 | 30 | Ecoli, Scerevisiae, Hsapiens_chr21 |
| Mapping | 30 | external rows appear as they complete |
| Variant calling | 30 | external rows appear as they complete |
| SV spike-in calling | 8 | Ecoli, Scerevisiae (donor with injected SVs) |
| Assembly | 29 | external rows appear as they complete |
| HiFi cross-platform | 6 | GCerrHMM route comparison |

## Layer status

| Species | Tool | Reads | Mapping | Variant | SV | Assembly |
|---|---|---|---|---|---|---|
| Athaliana | GCerrHMM | measured | measured | measured | missing | measured |
| Athaliana | GCerrHMM-1bin | measured | measured | measured | missing | measured |
| Athaliana | Sample-A | measured | measured | measured | missing | measured |
| Dmelanogaster | GCerrHMM | measured | measured | measured | missing | measured |
| Dmelanogaster | GCerrHMM-1bin | measured | measured | measured | missing | measured |
| Dmelanogaster | Sample-A | measured | measured | measured | missing | measured |
| Ecoli | GCerrHMM | measured | measured | measured | measured | measured |
| Ecoli | GCerrHMM-1bin | measured | measured | measured | missing | measured |
| Ecoli | NanoSim | measured | measured | measured | measured | measured |
| Ecoli | PBSim3-errhmm | measured | measured | measured | missing | missing |
| Ecoli | PBSim3-sample | measured | measured | measured | measured | measured |
| Ecoli | Sample-A | measured | measured | measured | missing | measured |
| Ecoli | badread | measured | measured | measured | measured | measured |
| Hsapiens_chr21 | GCerrHMM | measured | measured | measured | missing | measured |
| Hsapiens_chr21 | GCerrHMM-1bin | measured | measured | measured | missing | measured |
| Hsapiens_chr21 | NanoSim | measured | measured | measured | missing | measured |
| Hsapiens_chr21 | PBSim3-errhmm | measured | measured | measured | missing | missing |
| Hsapiens_chr21 | PBSim3-sample | measured | measured | measured | missing | measured |
| Hsapiens_chr21 | Real HiFi | missing | missing | missing | missing | measured |
| Hsapiens_chr21 | Real ONT | missing | missing | missing | missing | measured |
| Hsapiens_chr21 | Sample-A | measured | measured | measured | missing | measured |
| Hsapiens_chr21 | badread | measured | measured | measured | missing | measured |
| Mmusculus_chr19 | GCerrHMM | measured | measured | measured | missing | measured |
| Mmusculus_chr19 | GCerrHMM-1bin | measured | measured | measured | missing | measured |
| Mmusculus_chr19 | Sample-A | measured | measured | measured | missing | measured |
| Scerevisiae | GCerrHMM | measured | measured | measured | measured | measured |
| Scerevisiae | GCerrHMM-1bin | measured | measured | measured | missing | measured |
| Scerevisiae | NanoSim | measured | measured | measured | measured | measured |
| Scerevisiae | PBSim3-errhmm | measured | measured | measured | missing | missing |
| Scerevisiae | PBSim3-sample | measured | measured | measured | measured | measured |
| Scerevisiae | Sample-A | measured | measured | measured | missing | measured |
| Scerevisiae | badread | measured | measured | measured | measured | measured |
