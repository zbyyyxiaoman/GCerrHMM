# State-space ablation (3 seeds)

| Configuration | n | Composite | Read length | QV | GC | k-mer |
|---|---:|---:|---:|---:|---:|---:|
| full_states | 3 | 87.01±1.89 | 95.89±2.79 | 70.08±0.01 | 99.10±0.23 | 80.53±6.64 |
| simple_states | 3 | 86.48±1.44 | 93.28±0.33 | 70.09±0.00 | 98.45±0.69 | 81.57±7.41 |
