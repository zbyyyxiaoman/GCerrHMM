# Cross-tool comparison

| Species | Tool | Composite | Read length | QV | GC | k-mer |
|---|---|---:|---:|---:|---:|---:|
| Ecoli | nanosim | 84.47 | 88.0 | 64.28 | 97.23 | 86.59 |
