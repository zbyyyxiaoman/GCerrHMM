# R1 provenance

Every score is recomputed from the frozen Level-1 sub-score fields in the listed JSON file. The normalized locked weights are `0.15 read_length + 0.20 qv + 0.25 gc + 0.15 kmer`.

| Species | Route | Replicate | Frozen file | Composite line | Sub-scores line | File composite | Locked recompute | Delta |
|---|---|---:|---|---:|---:|---:|---:|---:|
| E. coli | A: Sample | 1 | `results/tables/level1_Ecoli_route_A_sample_r1.json` | 2711 | 2713 | 80.370000 | 80.367333 | 0.002667 |
| E. coli | A: Sample | 2 | `results/tables/level1_Ecoli_route_A_sample_r2.json` | 2711 | 2713 | 81.440000 | 81.443333 | 0.003333 |
| E. coli | B: qsHMM (1-bin) | 1 | `results/tables/level1_Ecoli_route_B_qshmm_r1.json` | 11711 | 11713 | 87.720000 | 87.722667 | 0.002667 |
| E. coli | B: qsHMM (1-bin) | 2 | `results/tables/level1_Ecoli_route_B_qshmm_r2.json` | 11711 | 11713 | 87.550000 | 87.555333 | 0.005333 |
| E. coli | C: errHMM (GC-aware) | 1 | `results/tables/level1_Ecoli_route_C_errhmm_r1.json` | 11711 | 11713 | 87.440000 | 87.443333 | 0.003333 |
| E. coli | C: errHMM (GC-aware) | 2 | `results/tables/level1_Ecoli_route_C_errhmm_r2.json` | 11711 | 11713 | 87.390000 | 87.390000 | 0.000000 |
| S. cerevisiae | A: Sample | 1 | `results/tables/level1_Scerevisiae_route_A_sample_r1.json` | 2711 | 2713 | 84.440000 | 84.444667 | 0.004667 |
| S. cerevisiae | A: Sample | 2 | `results/tables/level1_Scerevisiae_route_A_sample_r2.json` | 2711 | 2713 | 76.530000 | 76.530667 | 0.000667 |
| S. cerevisiae | B: qsHMM (1-bin) | 1 | `results/tables/level1_Scerevisiae_route_B_qshmm_r1.json` | 11711 | 11713 | 86.250000 | 86.245333 | 0.004667 |
| S. cerevisiae | B: qsHMM (1-bin) | 2 | `results/tables/level1_Scerevisiae_route_B_qshmm_r2.json` | 11711 | 11713 | 86.730000 | 86.731333 | 0.001333 |
| S. cerevisiae | C: errHMM (GC-aware) | 1 | `results/tables/level1_Scerevisiae_route_C_errhmm_r1.json` | 11711 | 11713 | 86.170000 | 86.170000 | 0.000000 |
| S. cerevisiae | C: errHMM (GC-aware) | 2 | `results/tables/level1_Scerevisiae_route_C_errhmm_r2.json` | 11711 | 11713 | 87.220000 | 87.216667 | 0.003333 |
| A. thaliana | A: Sample | 1 | `results/tables/level1_Athaliana_route_A_sample_r1.json` | 2711 | 2713 | 97.430000 | 97.435333 | 0.005333 |
| A. thaliana | A: Sample | 2 | `results/tables/level1_Athaliana_route_A_sample_r2.json` | 2711 | 2713 | 95.200000 | 95.197333 | 0.002667 |
| A. thaliana | B: qsHMM (1-bin) | 1 | `results/tables/level1_Athaliana_route_B_qshmm_r1.json` | 11711 | 11713 | 95.920000 | 95.916667 | 0.003333 |
| A. thaliana | B: qsHMM (1-bin) | 2 | `results/tables/level1_Athaliana_route_B_qshmm_r2.json` | 11711 | 11713 | 92.320000 | 92.316667 | 0.003333 |
| A. thaliana | C: errHMM (GC-aware) | 1 | `results/tables/level1_Athaliana_route_C_errhmm_r1.json` | 11711 | 11713 | 95.980000 | 95.976667 | 0.003333 |
| A. thaliana | C: errHMM (GC-aware) | 2 | `results/tables/level1_Athaliana_route_C_errhmm_r2.json` | 11711 | 11713 | 94.100000 | 94.096000 | 0.004000 |
| D. melanogaster | A: Sample | 1 | `results/tables/level1_Dmelanogaster_route_A_sample_r1.json` | 2711 | 2713 | 85.870000 | 85.872667 | 0.002667 |
| D. melanogaster | A: Sample | 2 | `results/tables/level1_Dmelanogaster_route_A_sample_r2.json` | 2711 | 2713 | 73.950000 | 73.952667 | 0.002667 |
| D. melanogaster | B: qsHMM (1-bin) | 1 | `results/tables/level1_Dmelanogaster_route_B_qshmm_r1.json` | 11711 | 11713 | 90.820000 | 90.816667 | 0.003333 |
| D. melanogaster | B: qsHMM (1-bin) | 2 | `results/tables/level1_Dmelanogaster_route_B_qshmm_r2.json` | 11711 | 11713 | 89.210000 | 89.209333 | 0.000667 |
| D. melanogaster | C: errHMM (GC-aware) | 1 | `results/tables/level1_Dmelanogaster_route_C_errhmm_r1.json` | 11711 | 11713 | 87.400000 | 87.400000 | 0.000000 |
| D. melanogaster | C: errHMM (GC-aware) | 2 | `results/tables/level1_Dmelanogaster_route_C_errhmm_r2.json` | 11711 | 11713 | 85.870000 | 85.869333 | 0.000667 |
| M. musculus chr19 | A: Sample | 1 | `results/tables/level1_Mmusculus_chr19_route_A_sample_r1.json` | 2711 | 2713 | 91.420000 | 91.421333 | 0.001333 |
| M. musculus chr19 | A: Sample | 2 | `results/tables/level1_Mmusculus_chr19_route_A_sample_r2.json` | 2711 | 2713 | 92.630000 | 92.627333 | 0.002667 |
| M. musculus chr19 | B: qsHMM (1-bin) | 1 | `results/tables/level1_Mmusculus_chr19_route_B_qshmm_r1.json` | 11711 | 11713 | 86.110000 | 86.111333 | 0.001333 |
| M. musculus chr19 | B: qsHMM (1-bin) | 2 | `results/tables/level1_Mmusculus_chr19_route_B_qshmm_r2.json` | 11711 | 11713 | 85.550000 | 85.550000 | 0.000000 |
| M. musculus chr19 | C: errHMM (GC-aware) | 1 | `results/tables/level1_Mmusculus_chr19_route_C_errhmm_r1.json` | 11711 | 11713 | 86.110000 | 86.110667 | 0.000667 |
| M. musculus chr19 | C: errHMM (GC-aware) | 2 | `results/tables/level1_Mmusculus_chr19_route_C_errhmm_r2.json` | 11711 | 11713 | 85.170000 | 85.172000 | 0.002000 |
| H. sapiens chr21 | A: Sample | 1 | `results/tables/level1_Hsapiens_chr21_route_A_sample_r1.json` | 2711 | 2713 | 83.560000 | 83.560667 | 0.000667 |
| H. sapiens chr21 | A: Sample | 2 | `results/tables/level1_Hsapiens_chr21_route_A_sample_r2.json` | 2711 | 2713 | 81.340000 | 81.335333 | 0.004667 |
| H. sapiens chr21 | B: qsHMM (1-bin) | 1 | `results/tables/level1_Hsapiens_chr21_route_B_qshmm_r1.json` | 11711 | 11713 | 84.770000 | 84.769333 | 0.000667 |
| H. sapiens chr21 | B: qsHMM (1-bin) | 2 | `results/tables/level1_Hsapiens_chr21_route_B_qshmm_r2.json` | 11711 | 11713 | 87.120000 | 87.120000 | 0.000000 |
| H. sapiens chr21 | C: errHMM (GC-aware) | 1 | `results/tables/level1_Hsapiens_chr21_route_C_errhmm_r1.json` | 11711 | 11713 | 84.830000 | 84.826000 | 0.004000 |
| H. sapiens chr21 | C: errHMM (GC-aware) | 2 | `results/tables/level1_Hsapiens_chr21_route_C_errhmm_r2.json` | 11711 | 11713 | 86.120000 | 86.122000 | 0.002000 |

Maximum file-vs-recompute delta: `0.00533333`. The same sub-score fields are used by fig3; the k-mer C-minus-B values used by fig4 are recomputed from the same frozen `kmer` sub-scores.

**Paired k-mer bootstrap.** `results/stats/kmer_pair_summary.csv` re-estimates the k-mer correlation with 1000 reads per side and a paired bootstrap over reads (200 resamples, same read indices for both routes). Eleven of twelve route/replicate comparisons have a difference interval containing zero; the single interval that excludes zero favours the 1-bin control and does not reproduce in the second replicate of the same genome. The six-species panel is therefore reported as not discriminable on this statistic.
