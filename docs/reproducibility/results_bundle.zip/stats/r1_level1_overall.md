# R1 Level-1 overall

Frozen aggregation only. Composite uses the locked weights with error-rate disabled and renormalization.

| Species | Route | n | Seeds/replicates | Mean ± SD | Raw values | k-mer mean | k-mer replicate spread |
|---|---|---:|---|---:|---|---:|---:|
| E. coli | A: Sample | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 80.9053 ± 0.7608 | 80.367333;81.443333 | 55.47 | 2.21 |
| E. coli | B: qsHMM (1-bin) | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 87.6390 ± 0.1183 | 87.722667;87.555333 | 83.27 | 3.33 |
| E. coli | C: errHMM (GC-aware) | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 87.4167 ± 0.0377 | 87.443333;87.390000 | 82.94 | 3.00 |
| S. cerevisiae | A: Sample | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 80.4877 ± 5.5960 | 84.444667;76.530667 | 49.38 | 41.15 |
| S. cerevisiae | B: qsHMM (1-bin) | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 86.4883 ± 0.3437 | 86.245333;86.731333 | 76.00 | 4.39 |
| S. cerevisiae | C: errHMM (GC-aware) | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 86.6933 ± 0.7401 | 86.170000;87.216667 | 76.88 | 2.47 |
| A. thaliana | A: Sample | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 96.3163 ± 1.5825 | 97.435333;95.197333 | 95.34 | 7.05 |
| A. thaliana | B: qsHMM (1-bin) | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 94.1167 ± 2.5456 | 95.916667;92.316667 | 84.61 | 16.70 |
| A. thaliana | C: errHMM (GC-aware) | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 95.0363 ± 1.3298 | 95.976667;94.096000 | 89.38 | 6.87 |
| D. melanogaster | A: Sample | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 79.9127 ± 8.4287 | 85.872667;73.952667 | 30.01 | 60.02 |
| D. melanogaster | B: qsHMM (1-bin) | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 90.0130 ± 1.1366 | 90.816667;89.209333 | 75.13 | 13.65 |
| D. melanogaster | C: errHMM (GC-aware) | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 86.6347 ± 1.0823 | 87.400000;85.869333 | 59.67 | 16.14 |
| M. musculus chr19 | A: Sample | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 92.0243 ± 0.8528 | 91.421333;92.627333 | 85.97 | 2.25 |
| M. musculus chr19 | B: qsHMM (1-bin) | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 85.8307 ± 0.3969 | 86.111333;85.550000 | 78.75 | 1.64 |
| M. musculus chr19 | C: errHMM (GC-aware) | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 85.6413 ± 0.6637 | 86.110667;85.172000 | 79.44 | 3.84 |
| H. sapiens chr21 | A: Sample | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 82.4480 ± 1.5735 | 83.560667;81.335333 | 37.82 | 11.98 |
| H. sapiens chr21 | B: qsHMM (1-bin) | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 85.9447 ± 1.6622 | 84.769333;87.120000 | 56.08 | 7.52 |
| H. sapiens chr21 | C: errHMM (GC-aware) | 2 | legacy r1/r2; seed not persisted (generator default seed=42) | 85.4740 ± 0.9164 | 84.826000;86.122000 | 54.38 | 2.06 |

**Read this table with the k-mer column open.** The composite contains no term that measures the error rate conditional on local GC, and its k-mer term is noisy: the replicate-to-replicate spread of that sub-score reaches 60.0 points on a 0-100 scale within a single route. Comparing the GC-aware route with the 1-bin control on this table is therefore reported as **not discriminable**, not as a win for either route; see `docs/gc_claim_evidence_chain.md` for the pre-registered instruments that do carry that claim.
