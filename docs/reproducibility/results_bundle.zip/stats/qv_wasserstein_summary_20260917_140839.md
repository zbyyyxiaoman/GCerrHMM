# QV Wasserstein summary

| Species | Route | n | Mean score | SD |
|---|---|---:|---:|---:|
| Athaliana | route_A_sample | 2 | 94.50 | 0.00 |
| Athaliana | route_B_qshmm | 2 | 94.50 | 0.00 |
| Athaliana | route_C_errhmm | 2 | 94.50 | 0.00 |
| Dmelanogaster | route_A_sample | 2 | 88.01 | 0.00 |
| Dmelanogaster | route_B_qshmm | 2 | 88.01 | 0.00 |
| Dmelanogaster | route_C_errhmm | 2 | 88.01 | 0.01 |
| Ecoli | route_A_sample | 2 | 61.36 | 0.00 |
| Ecoli | route_B_qshmm | 2 | 61.36 | 0.01 |
| Ecoli | route_C_errhmm | 2 | 61.37 | 0.00 |
| Hsapiens_chr21 | route_A_sample | 2 | 87.92 | 0.00 |
| Hsapiens_chr21 | route_B_qshmm | 2 | 87.92 | 0.01 |
| Hsapiens_chr21 | route_C_errhmm | 2 | 87.92 | 0.00 |
| Mmusculus_chr19 | route_A_sample | 2 | 89.18 | 0.00 |
| Mmusculus_chr19 | route_B_qshmm | 2 | 89.18 | 0.00 |
| Mmusculus_chr19 | route_C_errhmm | 2 | 89.18 | 0.00 |
| Scerevisiae | route_A_sample | 2 | 78.71 | 0.01 |
| Scerevisiae | route_B_qshmm | 2 | 78.71 | 0.03 |
| Scerevisiae | route_C_errhmm | 2 | 78.70 | 0.01 |
