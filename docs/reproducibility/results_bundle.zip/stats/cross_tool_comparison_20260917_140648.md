# Cross-tool comparison

| Species | Tool | Composite | Read length | QV | GC | k-mer |
|---|---|---:|---:|---:|---:|---:|
| Ecoli | nanosim | 84.47 | 88.0 | 64.28 | 97.23 | 86.59 |
| Ecoli | pbsim | 94.19 | 90.99 | 100.0 | 98.58 | 82.3 |
