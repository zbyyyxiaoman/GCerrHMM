# Coverage ablation (3 replicates)

| Coverage | n | Mean | SD |
|---|---:|---:|---:|
| 1x | 3 | 73.24 | 0.00 |
| 5x | 3 | 73.77 | 0.00 |
| 10x | 3 | 75.24 | 0.00 |
| 30x | 3 | 76.61 | 0.00 |
