# Composite Score Card

| Species | Method | Replicates | Mean Score | Std | Best | Worst |
|---|---|---|---|---|---|---|
| Ecoli | Sample | 2 | 80.91 | 0.53 | 81.44 | 80.37 |
| Ecoli | qsHMM(nongc) | 2 | 87.10 | 1.84 | 88.94 | 85.26 |
| Ecoli | errHMM (Ours) | 2 | 87.03 | 0.11 | 87.14 | 86.92 |
| Scerevisiae | Sample | 2 | 80.48 | 3.95 | 84.44 | 76.53 |
| Scerevisiae | qsHMM(nongc) | 2 | 82.81 | 3.70 | 86.51 | 79.12 |
| Scerevisiae | errHMM (Ours) | 2 | 85.47 | 4.16 | 89.62 | 81.31 |
| Athaliana | Sample | 2 | 96.31 | 1.12 | 97.43 | 95.20 |
| Athaliana | qsHMM(nongc) | 2 | 94.84 | 1.52 | 96.36 | 93.31 |
| Athaliana | errHMM (Ours) | 2 | 94.44 | 0.63 | 95.07 | 93.80 |
| Dmelanogaster | Sample | 2 | 79.91 | 5.96 | 85.87 | 73.95 |
| Dmelanogaster | qsHMM(nongc) | 2 | 84.61 | 0.52 | 85.12 | 84.09 |
| Dmelanogaster | errHMM (Ours) | 2 | 87.62 | 4.91 | 92.53 | 82.72 |
| Mmusculus_chr19 | Sample | 2 | 92.03 | 0.60 | 92.63 | 91.42 |
| Mmusculus_chr19 | qsHMM(nongc) | 2 | 91.41 | 0.31 | 91.72 | 91.10 |
| Mmusculus_chr19 | errHMM (Ours) | 2 | 91.57 | 0.05 | 91.63 | 91.52 |
| Hsapiens_chr21 | Sample | 2 | 82.45 | 1.11 | 83.56 | 81.34 |
| Hsapiens_chr21 | qsHMM(nongc) | 2 | 81.09 | 2.41 | 83.50 | 78.68 |
| Hsapiens_chr21 | errHMM (Ours) | 2 | 82.36 | 1.15 | 83.51 | 81.21 |
