# Cross-Species GC-bin Ablation

| Species | GC bins | Composite score |
|---|---|---:|
| Ecoli | 5bin | 74.45 |
| Ecoli | 10bin | 76.42 |
| Ecoli | 20bin | 73.85 |
| Athaliana | 5bin | 77.35 |
| Athaliana | 10bin | 77.91 |
| Athaliana | 20bin | 74.43 |
