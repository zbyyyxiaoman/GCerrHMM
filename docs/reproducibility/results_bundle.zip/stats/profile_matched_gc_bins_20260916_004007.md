# Profile-matched GC-bin ablation

| Species | GC bins | Composite score |
|---|---|---:|
| Ecoli | 1bin | 85.32 |
| Ecoli | 5bin | 86.11 |
| Ecoli | 10bin | 86.42 |
| Ecoli | 20bin | 87.93 |
| Athaliana | 1bin | 95.26 |
| Athaliana | 5bin | 90.88 |
| Athaliana | 10bin | 97.38 |
| Athaliana | 20bin | 96.37 |
