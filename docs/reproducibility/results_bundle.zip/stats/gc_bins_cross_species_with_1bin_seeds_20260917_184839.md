# GC-bin cross-species table (3 seeds)

| Species | GC bins | n | Mean | SD |
|---|---:|---:|---:|---:|
| Ecoli | 1bin | 3 | 84.90 | 1.90 |
| Ecoli | 5bin | 3 | 87.55 | 0.14 |
| Ecoli | 10bin | 3 | 86.92 | 2.32 |
| Ecoli | 20bin | 3 | 86.57 | 2.97 |
| Athaliana | 1bin | 3 | 92.81 | 4.02 |
| Athaliana | 5bin | 3 | 96.35 | 1.07 |
| Athaliana | 10bin | 3 | 93.16 | 2.73 |
| Athaliana | 20bin | 3 | 96.62 | 0.99 |
