# Cross-tool comparison

| Species | Tool | Composite | Read length | QV | GC | k-mer |
|---|---|---:|---:|---:|---:|---:|
| Ecoli | errhmm | 87.03 | 94.28 | 70.08 | 99.055 | 82.33 |
| Ecoli | nanosim | 84.47 | 88.0 | 64.28 | 97.23 | 86.59 |
| Ecoli | pbsim | 94.19 | 90.99 | 100.0 | 98.58 | 82.3 |
| Ecoli | badread | 79.93 | 96.71 | 52.93 | 96.89 | 70.91 |
| Scerevisiae | errhmm | 85.465 | 91.02 | 95.88 | 83.38 | 69.5 |
| Hsapiens_chr21 | errhmm | 82.36 | 97.865 | 97.24 | 86.29499999999999 | 40.480000000000004 |
