# Cross-Species GC-bin Ablation with 1-bin Control

| Species | GC bins | Composite score |
|---|---|---:|
| Ecoli | 1bin | 75.6 |
| Ecoli | 5bin | 74.45 |
| Ecoli | 10bin | 76.42 |
| Ecoli | 20bin | 73.85 |
| Athaliana | 1bin | 75.04 |
| Athaliana | 5bin | 77.35 |
| Athaliana | 10bin | 77.91 |
| Athaliana | 20bin | 74.43 |
