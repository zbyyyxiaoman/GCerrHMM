# Coverage ablation (3 replicates)

| Coverage | n | Mean | SD |
|---|---:|---:|---:|
| 1x | 3 | 75.81 | 1.32 |
| 5x | 3 | 74.64 | 2.65 |
| 10x | 3 | 75.42 | 0.42 |
| 30x | 3 | 74.78 | 0.18 |
