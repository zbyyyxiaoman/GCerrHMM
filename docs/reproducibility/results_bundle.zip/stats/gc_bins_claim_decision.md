# GC-bin ablation: pre-registered claim decision

Rule: `docs/gc_claim_evidence_chain.md`. Primary instrument: GC-conditional error fidelity (Pearson r against the real per-bin error rate, and MAD).

Data completeness: complete

| species | GC bins | n | mean r | r SD | mean MAD (pp) | MAD SD (pp) |
|---|---|---:|---:|---:|---:|---:|
| E. coli | 1 | 3 | 0.077 | 0.334 | 0.255 | 0.006 |
| E. coli | 5 | 3 | -0.080 | 0.571 | 0.252 | 0.004 |
| E. coli | 10 | 3 | 0.233 | 0.504 | 0.258 | 0.003 |
| E. coli | 20 | 3 | 0.576 | 0.184 | 0.266 | 0.007 |
| A. thaliana | 1 | 3 | 0.779 | 0.062 | 4.204 | 0.010 |
| A. thaliana | 5 | 3 | 0.960 | 0.011 | 4.212 | 0.039 |
| A. thaliana | 10 | 3 | 0.970 | 0.002 | 4.475 | 0.015 |
| A. thaliana | 20 | 3 | 0.981 | 0.004 | 4.398 | 0.039 |

## Per-species checks

* **E. coli**: 1-bin worst = False (lowest r: False, highest MAD: False, r gap > SD: False, MAD gap > SD: False)
* **A. thaliana**: 1-bin worst = False (lowest r: True, highest MAD: False, r gap > SD: True, MAD gap > SD: False)

## Branch

**Contracted branch**: the claim contracts to a trainable GC-aware simulation framework with competitive compositional and downstream fidelity; GC conditioning is reported as a design feature rather than a performance claim. Write this branch with the same prominence as the accepted one would have received.
