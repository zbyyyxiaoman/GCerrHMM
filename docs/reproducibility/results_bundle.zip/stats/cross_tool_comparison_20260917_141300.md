# Cross-tool comparison

| Species | Tool | Composite | Read length | QV | GC | k-mer |
|---|---|---:|---:|---:|---:|---:|
| Ecoli | nanosim | 84.47 | 88.0 | 64.28 | 97.23 | 86.59 |
| Ecoli | pbsim | 94.19 | 90.99 | 100.0 | 98.58 | 82.3 |
| Ecoli | badread | 79.93 | 96.71 | 52.93 | 96.89 | 70.91 |
| Scerevisiae | nanosim | 70.98 | 99.71 | 87.87 | 82.82 | 0.0 |
| Scerevisiae | pbsim | 76.88 | 94.46 | 99.75 | 83.72 | 17.41 |
| Scerevisiae | badread | 81.55 | 97.56 | 91.5 | 83.77 | 48.57 |
| Hsapiens_chr21 | nanosim | 74.82 | 93.5 | 92.12 | 64.89 | 49.62 |
| Hsapiens_chr21 | pbsim | 80.98 | 97.25 | 100.0 | 83.65 | 34.92 |
