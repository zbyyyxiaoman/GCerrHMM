| Species | Analyzed reference | Size (Mb) | GC (%) | GC heterogeneity (SD) | Reference assembly | ONT read accession |
|---|---|---:|---:|---:|---|---|
| E. coli | E. coli (full) | 4.64 | 50.79 | 4.80 | GCF_000005845.2 | SRR39619343 |
| S. cerevisiae | S. cerevisiae (full) | 12.16 | 38.15 | 3.83 | GCF_000146045.2 | SRR39791672 |
| A. thaliana | A. thaliana (full) | 119.67 | 36.06 | 5.51 | GCF_000001735.2 | ERR5716408 |
| D. melanogaster | D. melanogaster (full) | 143.73 | 42.01 | 6.34 | GCF_000001215.4 | SRR22071686 |
| M. musculus chr19 | M. musculus chr19 | 61.45 | 42.72 | 5.69 | GCF_000001635.27 | SRR14685232 |
| H. sapiens chr21 | H. sapiens chr21 | 51.46 | 41.16 | 8.17 | GCF_000001405.40 | ERR13491992 |
