# Paper locked conclusions

Status: frozen for the writing sprint on 2026-09-18.

## Locked claims

1. GC-aware modeling is better than GC-unaware modeling:
   1-bin is at the bottom for both Ecoli and Athaliana, with a consistent
   direction across 3 seeds.
2. The optimal number of GC bins is genome-dependent. Do not claim a
   universal 10-bin optimum.
3. The simplified state space is sufficient in practice:
   full `87.01±1.89` vs simple `86.48±1.44` across 3 seeds.
4. Coverage results are described as robust in the 1x-30x range.
   Do not claim that more training coverage is always better.
5. Cross-tool results are species-dependent:
   PBSim3 is strongest on Ecoli and Hsapiens_chr21 distributional metrics;
   errHMM is strongest on Scerevisiae and remains competitive on the
   eukaryotic genomes.

## Locked limitations

- The error-rate sub-score was not enabled in the final composite.
  A sensitivity analysis is future work.
- The HiFi cross-platform branch is unavailable because the available
  `Ecoli_hifi.fastq.gz` is short-read data (`mean length 69.84 bp`).
  Do not run the wrong data through the HiFi branch.
- The composite is a Level-1 distributional similarity score, not a
  universal measure of biological correctness.

## Evidence

- `docs/kmer_metric_audit.md`
- `docs/composite_evaluation_protocol.md`
- `docs/final_cross_tool_comparison.md`
- `results/stats/state_space_seeds_20260917_183439.md`
- `results/stats/profile_matched_gc_bins_seeds_20260916_010047.md`
- `results/stats/coverage_replicates_20260917_142457.md`
