# Paper visual package

Generated from the frozen data snapshot on 2026-09-18. No simulation,
training, or result-file changes were made for this package.

## Visuals

- `fig1_workflow_diagram.png/.pdf`
- `table1_species_panel.png/.pdf/.csv/.md`
- `fig3_subscore_heatmap.png/.pdf`
- `fig4_kmer_gain.png/.pdf`
- `fig5_cross_tool_heatmap.png/.pdf`
- `fig6_coverage_state_space_errorbars.png/.pdf`

## Supporting text

- `figure_captions.md`
- `methods_parameters.md`
- `composite_evaluation_protocol.md`
- `kmer_metric_audit.md`
- `final_cross_tool_comparison.md`
- `data_freeze_manifest.md`
- `paper_locked_conclusions.md`
