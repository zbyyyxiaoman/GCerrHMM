# Figure numbering map

The frozen Phase 7 files in `results/figures/` remain untouched for
reproducibility. The writing sprint uses the following explicit mapping so
that legacy filenames cannot be mistaken for the final paper figures.

| Paper item | Final working file |
|---|---|
| Figure 1 | `docs/paper_figures/fig1_workflow_diagram.png/.pdf` |
| Figure 2 | `docs/paper_figures/fig2_gc_error_heatmap.png` |
| Table 1 | `docs/paper_figures/table1_species_panel.png/.pdf` |
| Figure 3 | `docs/paper_figures/fig3_subscore_heatmap.png/.pdf` |
| Figure 4 | `docs/paper_figures/fig4_kmer_gain.png/.pdf` |
| Figure 5 | `docs/paper_figures/fig5_cross_tool_heatmap.png/.pdf` |
| Figure 6 | `docs/paper_figures/fig6_coverage_state_space_errorbars.png/.pdf` |
| Supplementary Figure S1 | `docs/paper_innovation/figA_gc_error_curve.png/.pdf` |
| Supplementary Figure S2 | `docs/paper_innovation/figB_homopolymer_deletion.png/.pdf` |
| Supplementary Figure S3 | `docs/paper_innovation/figC_kmer_pca.png/.pdf` |
| Supplementary Figure S4 | `docs/paper_innovation/figD_gc_heterogeneity_gain.png/.pdf` |
| Supplementary Figure S5 | `docs/paper_innovation/figE_simulator_selection_guide.png/.pdf` |

The legacy `results/figures/fig*` files are frozen provenance artifacts,
not the submission filenames. No frozen result file was moved or renamed.
